        function LocalStorage(db) {
            this.db=db;
            this.dataCache = new Array();
        }

        LocalStorage.prototype.setItem = function( name, value ) 
        {
            try
            {
                this.dataCache[name] = value;
                if ( this.db.transaction )
                {
                    this.db.transaction(function(tx) 
                    {
                        try
                        {
                            tx.executeSql("INSERT INTO KeyValues (name, value) VALUES (?, ?)", [name, value], 
                                    function(tx, result) {  }, 
                                    function(tx, error) {  });
                        }
                        catch(ex)
                        {
                            alert("Exception: " + ex.message);
                        }
                    });
                }
                else if ( this.db.getAttribute("props") != null )
                {
                    var nameListString = this.db.getAttribute("props");
                    nameListString = nameListString.replace("-=-"+name,"");
                    nameListString = nameListString + "-=-" + name;
                    this.db.setAttribute(name, value);
                    this.db.setAttribute("props", nameListString);
                    this.db.save("oXMLBranch");
                }
            }
            catch(ex)
            {
                alert("Exception outer: " + ex.message);
            }

        }
           
        LocalStorage.prototype.getItem = function( name )
        {
            if ( this.dataCache && this.dataCache[name] )
                return this.dataCache[name];
            else
                return null;
        }

        LocalStorage.prototype.init = function() 
        {
            try
            {
                if ( this.db.transaction )
                {
                    this.db.transaction(function(tx) 
                    {
                        tx.executeSql("SELECT * FROM KeyValues", [], 
                                function(tx, result) {
                                    var rows = result.rows;
                                    for ( var rowCt = 0; rowCt < rows.length; rowCt++ )
                                    {
                                        var row = rows.item(rowCt);
                                        localStorage.dataCache[row['name']] = row['value'];
                                      
                                    }
                                }, 
                                function(tx, error) {
                                    tx.executeSql("CREATE TABLE KeyValues(id INT UNIQUE, name TEXT, value TEXT)", [], 
                                            function(tx,result) 
                                            { 
                                                tx.executeSql("INSERT INTO KeyValues (name, value) VALUES (?, ?)", ["created", new Date().getTime()+""], 
                                                    function(tx,result) {},
                                                    function(tx,error){ alert("Error2: "+error); }); 
                                            },
                                            function(tx,error){alert("Error2: "+error);});
                                });
                    });
                }
            }
            catch(err) {}

            try
            {
                var nodes = "";
                if ( this.db && this.db.load )
                {
                    this.db.load("oXMLBranch");
                    var nameListString = this.db.getAttribute("props");
                    if ( nameListString )
                    {
                        var nameList = nameListString.split(/-=-/);
                        for ( var nCt = 0; nCt < nameList.length; nCt++ )
                        {
                            var propName = nameList[nCt];
                            this.dataCache[propName] = this.db.getAttribute(propName);
                            nodes += propName +" ";
                        }
                    }
                    else
                    {
                        this.db.setAttribute("props","");
                    }
                }
            }
            catch(ex) { 
                //alert("Node ex: " + ex.message); 
            }
        }

        var db = null;
        function InitializeDB()
        {
            try
            {
                try
                {
                    if (window.openDatabase) 
                    {
                        db = openDatabase("Soovle", "1.0", "Database for local data", 200000);
                        if (!db)
                        {
                            alert("Failed to open the database on disk.  This is probably because the version was bad or there is not enough space left in this domain's quota");
                        }
                    } 
                    else
                    {
                        db = document.getElementById("datastore");
                    }
                } 
                catch(err) { }

                if ( db.transaction )
                {
                    db.transaction(function(tx) 
                    {
                        tx.executeSql("SELECT COUNT(*) FROM Data", [], 
                                function(result) {
                                }, 
                                function(tx, error) {
                                    tx.executeSql("CREATE TABLE Data (id INT UNIQUE, amount REAL, timestamp INT)", [], 
                                            function(tx,result) 
                                            { 
                                                var curTime = new Date().getTime();
                                                tx.executeSql("INSERT INTO Data (amount, timestamp) VALUES (?, ?)", [0, curTime], 
                                                    function(tx,result) {},
                                                    function(tx,error){ alert("Error2: "+error); }); 
                                            },
                                            function(tx,error){alert("Error2: "+error);});
                                });
                    });
                }

                localStorage = new LocalStorage(db);
                try
                {
                    localStorage.init();
                }
                catch(exInit)
                {
                    alert("Exception of init: " + exInit.message);
                }
            }
            catch(ex)
            {
                alert("Error in initialize.: " + ex.message);
                throw ex;
            }
        }

