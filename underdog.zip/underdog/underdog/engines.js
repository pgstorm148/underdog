
var feedTypes = {
    "external": 1,
    "local": 2
};

var deadEngines = {"cuil":1};
var enginesName = "enginesv0"

var providerIndex = { "google": 0,
                      "amazon": 1,
                      "yahoo": 2,
                      "ask": 3,
                      "youtube": 4,
                      "ebay": 5,
                      "wikipedia": 6,
                      "live": 7,
                      "answers": 8,
                      "buy": 9,
                      "overstock":10,
                      "walmart":11
                    };

var providers = []; //All search providers
var providerLookup = []; //All search providers
var searchDivs = [];//Currently in-use providers
var allProviders = [];

function providerObject( name, position, favicon, logo, searchUrl /*commit the search*/, searchResultsUrl /*search results*/, site /*e.g. site:amazon.com*/, feedUrl, feedType)
{
    this.name = name;
    this.index = providerIndex[name];
    this.position = position;
    this.favicon = favicon;
    this.logo = logo;
    this.searchUrl = searchUrl;
    this.searchResultsUrl = searchResultsUrl;
    this.site = site;
    this.feedUrl = feedUrl;
    this.feedType = feedType;
    this.visible = false;

};

providerObject.prototype.SetEncoding = function(provEnc)
{
    this.encoding = provEnc;
}

providerObject.prototype.BuildDiv = function()
{
    var divContainer = document.getElementById("divscontainer");
    var dataDiv = document.createElement("div");
    dataDiv.className = "provider";
    dataDiv.id = this.name;
    dataDiv.style.position = "absolute";
    dataDiv.style.display = "none";
    dataDiv.style.opacity = "0";
    dataDiv.style.overflow= "visible";
    divContainer.appendChild(dataDiv);

    var imgDiv = document.createElement("img");
    setTimeout((function(img,imgSrc) { return (function() { img.src=imgSrc; }); })(imgDiv,this.logo),10);
    //imgDiv.src = this.logo;
    imgDiv.id = this.name + "img";
    $(imgDiv).css({
        maxWidth:190
    });
    dataDiv.appendChild(imgDiv);

    var completeDiv = document.createElement("div");
    completeDiv.id = this.name + "complete";
    completeDiv.style.position = "absolute";
    completeDiv.style.width = "190px";
    completeDiv.style.filter = "alpha(opacity=100)";
    dataDiv.appendChild(completeDiv);

    this.searchDiv = dataDiv;
    this.completeDiv = completeDiv;
}

providerObject.prototype.Hide = function( useGrace ) {
    if ( this.visible ) {
        if ( useGrace ) {
            $(this.searchDiv).hide("slow");
        } else {
            this.searchDiv.style.display = "none";
        }

        this.visible = false;
    }
}

providerObject.prototype.Show = function( useGrace)
{
    if ( !this.visible )
    {
        if ( useGrace )
        {
            this.searchDiv.style.display = "";
            $(this.searchDiv).animate({opacity:"1"},"slow");
        }
        else
        {
            this.searchDiv.style.display = "";
        }

        this.visible = true;
    }
}

providerObject.prototype.SetPosition = function( posIndex, useGrace, placements)
{
    this.position = posIndex;
    var curPos = placements.positions[ posIndex % placements.positions.length ];
    this.SetPositionXY( curPos.x, curPos.y, useGrace);
}

providerObject.prototype.SetPositionXY = function( x, y, useGrace)
{
    if ( useGrace )
        $(this.searchDiv).animate({left:x, top:y}, "slow");
    else
    {
        this.searchDiv.style.left = x + "px";
        this.searchDiv.style.top = y + "px";
    }
}

var googleprov;
var amazon;
var wikipedia;
var ask;
var answers;
var youtube;
var yahoo;
var buy;
var overstock;
var walmart;

function BuildProviders() {
    googleprov = new providerObject( "google", providerObject.google,
                                     "https://dqmlg7taqp2lg.cloudfront.net/googlefavicon.png", 
                                     "https://dqmlg7taqp2lg.cloudfront.net/google.png", 
                                     "https://www.google.com/search?hl=en&btnG=Google+Search&aq=f&oq=&q=", 
                                     null, //"http://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     null, 
                                     "https://soovle.com/google?q=",
                                     feedTypes.external); 
    googleprov.BuildDiv();

    providers["google"] = googleprov;
    allProviders[allProviders.length] = googleprov;
    providerLookup[providerIndex.google] = googleprov;

    amazon = new providerObject( "amazon", providerObject.amazon, 
                                     "https://www.amazon.com/favicon.ico", 
                                     "https://dqmlg7taqp2lg.cloudfront.net/amazon.png", 
                                     "https://www.amazon.com/s/?url=search-alias%3Daps&x=0&y=0&tag=rpi07-20&field-keywords=", 
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "amazon.com",
                                     "https://completion.amazon.com/search/complete?mkt=1&search-alias=aps&x=updateAmazon&q=", 
                                     feedTypes.external); 
    amazon.BuildDiv();

    providers["amazon"] = amazon;
    providerLookup[providerIndex.amazon] = amazon;
    allProviders[allProviders.length] = amazon;


    yahoo = new providerObject( "yahoo", providerObject.yahoo, 
                                     "https://www.yahoo.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/yahool.png",
                                     "https://search.yahoo.com/search?fr=yfp-t-501&toggle=1&cop=mss&ei=UTF-8&p=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     null, 
                                     "https://sugg.search.yahoo.net/sg/?output=fxjsonp&nresults=10&command=",
                                     feedTypes.external); 
    yahoo.BuildDiv();

    providers["yahoo"] = yahoo;
    allProviders[allProviders.length] = yahoo;
    providerLookup[providerIndex.yahoo] = yahoo;

    ask = new providerObject( "ask", providerObject.ask, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/askfavicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/ask.png",
                                     "https://www.ask.com/web?search=search&qsrc=0&o=0&l=dir&q=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     null, 
                                     "https://ss.ask.com/query?fn=updateAsk&sstype=prefix&q=",
                                     feedTypes.external); 
    ask.BuildDiv();

    providers["ask"] = ask;
    allProviders[allProviders.length] = ask;
    providerLookup[providerIndex.ask] = ask;

    youtube = new providerObject( "youtube", providerObject.youtube,
                                     "https://www.youtube.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/youtube.gif",
                                     "https://www.youtube.com/results?search_type=&aq=f&search_query=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "youtube.com", 
                                     "https://clients1.google.com/complete/search?client=youtube&hl=en&gl=us&ds=yt&cp=1&gs_id=5&callback=window.google.ac.jsonRPCDone&q=",
                                     feedTypes.external); 
    youtube.BuildDiv();

    providers["youtube"] = youtube;
    allProviders[allProviders.length] = youtube;
    providerLookup[providerIndex.youtube] = youtube;

    answers = new providerObject( "answers", providerObject.answers,
                                     "https://www.answers.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/answers_logo_sm.jpg",
                                     "https://www.answers.com/search?q=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "answers.com", 
                                     "https://soovle.com/answers?q=",
                                     feedTypes.local); 
    answers.BuildDiv();

    providers["answers"] = answers;
    allProviders[allProviders.length] = answers;
    providerLookup[providerIndex.answers] = answers;

    wikipedia = new providerObject( "wikipedia", providerObject.wikipedia, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/wikifavicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/wikipedia.png",
                                     "https://en.wikipedia.org/wiki/",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "wikipedia.com", 
                                     "https://theamackers.com/wiki?q=",
                                     feedTypes.local); 
    wikipedia.BuildDiv();
    providers["wikipedia"] = wikipedia;
    allProviders[allProviders.length] = wikipedia;
    providerLookup[providerIndex.wikipedia] = wikipedia;

    live = new providerObject( "live", providerObject.live, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/msnfav.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/bing.png",
                                     "https://www.bing.com/search?go=&form=QBLH&qs=n&q=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     null, 
                                     //"http://api.search.live.com/qson.aspx?market=en-US&options=EnableSuggestionType&JsonType=callback&JsonCallback=sas_SearchAutoSuggest.setData&query=",
                                     "https://api.bing.com/osjson.aspx?language=EN-US&form=OSDJAS&JsonType=callback&JsonCallback=sas_SearchAutoSuggest.setData&query=",
                                     feedTypes.external); 
    live.BuildDiv();
    providers["live"] = live;
    allProviders[allProviders.length] = live;
    providerLookup[providerIndex.live] = live;

    ebay = new providerObject( "ebay", providerObject.ebay, 
                                     "https://www.ebay.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/logoEbay_x45.gif",
                                     "https://shop.ebay.com/?_from=R40&_trksid=m38&_nkw=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "", 
                                     "https://autosug.ebay.com/autosug?_jgr=1&sId=0&_ch=0&callback=updateEbay&kwd=", 
                                     feedTypes.external); 
    ebay.BuildDiv();
    providers["ebay"] = ebay;
    allProviders[allProviders.length] = ebay;
    providerLookup[providerIndex.ebay] = ebay;

    buy = new providerObject( "buy", providerObject.buy, 
                                     "https://www.rakuten.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/buycom.gif",
                                     "https://affiliate.buy.com/deeplink?id=pbC9zvV6XSI&mid=36342&murl="+encodeURIComponent("http://www.buy.com/sr/searchresults.aspx?qxt=home&display=col&qu="),
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "buy.com",
                                     "https://na.api.suggest.search.global.rakuten.com/suggest?cl=usamall&h=10&rw_count=10&sid=122&oe=utf-8&rid=0465659369&cb=updateBuy&q=",
                                     feedTypes.external); 
    buy.BuildDiv();
    providers["buy"] = buy;
    allProviders[allProviders.length] = buy;
    providerLookup[providerIndex.buy] = buy;

    overstock = new providerObject( "overstock", providerObject.overstock, 
                                     "https://theamackers.com/oco.ico",
                                     "https://theamackers.com/oco.png",
                                     "https://www.overstock.com/search?SearchType=Header&keywords=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "overstock.com", 
                                     "https://theamackers.com/oco?q=",
                                     feedTypes.external); 
    overstock.BuildDiv();
    providers["overstock"] = overstock;
    allProviders[allProviders.length] = overstock;
    providerLookup[providerIndex.overstock] = overstock;

    walmart = new providerObject( "walmart", providerObject.walmart, 
                                     "https://www.walmart.com/favicon.ico",
                                     "https://i2.walmartimages.com/i/header_wide/walmart_logo_214x54.gif",
                                     "https://www.walmart.com/search/search-ng.do?ic=48_0&Find=Find&search_constraint=0&search_query=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     null, 
                                     "https://www.walmart.com/search/autocomplete/v1/0/",
                                     feedTypes.external); 


    walmart.BuildDiv();
    providers["walmart"] = walmart;
    allProviders[allProviders.length] = walmart;
    providerLookup[providerIndex.walmart] = walmart;
}

var activeProviders = [];
function BuildProvidersFromList(providerString, providerCount) {
    try {
        var maxProviders = 7;
        if ( providerCount && providerCount > 4 ) {
            maxProviders = providerCount;
        }

        var providerList = engines;
        if ( providerString && (providerString+"").match(/,/) ) {
            providerList = (providerString+"").split(/,/);

            if ( !providerList ) {
                providerList = engines;
            }

            if ( !providerCount )
                maxProviders = providerList.length;

            providerList = providerList.concat(engines);
        } else {
            if ( window.innerHeight > 900 ) {
                maxProviders = 11;
            }

            if ( window.innerHeight > 1300 ) {
                maxProviders = 15;
            }

            providerList = engines;
        }

        var added = [];
        searchDivs = [];
        activeProviders = [];
        for ( var pCt = 0; pCt < providerList.length && searchDivs.length < maxProviders; pCt++ )
        {
            if ( added[providerList[pCt]] == null )
            {
                added[providerList[pCt]] = 1;
                searchDivs[searchDivs.length] = providers[providerList[pCt]];
                activeProviders[activeProviders.length] = providerList[pCt];
                providers[providerList[pCt]].Show(true);
            }
        }

        InstallSelectors();
    } catch(ex) {
        console.log("Build providers: " + ex.message);
    }
}

function RebuildProviders(newList, count, noTrigger) {
  for ( var pCt = 0; pCt < allProviders.length; pCt++ ) {
    allProviders[pCt].Hide();
  }

  StoreEngineSet( newList );
  BuildProvidersFromList(newList, count);
  PlaceProvider(0, false);
}

function StoreEngineSet( engineSet )
{
    localStorage.setItem(enginesName, engineSet);
}

function RestoreEngines() {
    var engine = (window.location.href + "" ).replace(/.*s=([^&]+).*/,"$1");

    if ( !engines || ( engine && engine == window.location.href + "" )) {
        var engineval = localStorage.getItem(enginesName);
        if ( engineval != null ) {
           try {
               RebuildProviders(engineval);
           } catch(ex) { 
             console.log("Exception rebuilding: " + ex.message);
           }
        }
    }
}

function ReloadEngines(count) {
    var engineval = localStorage.getItem(enginesName);
    if ( engineval != null ) {
       RebuildProviders(engineval, count);
    }
}

function ClearEngineCustomization() {
    localStorage.setItem(enginesName, null);
    for ( var pCt = 0; pCt < allProviders.length; pCt++ ) {
        allProviders[pCt].Hide();
    }
    BuildProvidersFromList();
}

window.google = { ac: { yup: "t" } };
window.google.ac.h = function (dataObj)
{
    var img = $('#googleimg')[0];
    if ( !img.seeThrough )
    {
        img.seeThrough = true;
        img.style.position = "absolute";
        $(img).stop().animate({opacity:".3"},300);
    }

    var gData = $('#googlecomplete')[0];
    while ( gData.firstChild ) {
        gData.removeChild(gData.firstChild);
    }

    var corArray = dataObj[1];
    completions[providerIndex.google] = [];
    for ( var gdCt = 0; gdCt < corArray.length; gdCt++ ) {
        var curCor = corArray[gdCt];
        if (Array.isArray(curCor))
          curCor = curCor[0];
        if (curCor) {
          var div = AddSuggestion(gData, curCor, providerIndex.google);
          completions[providerIndex.google][gdCt] = div;
        }
    }
}

window.google.ac.jsonRPCDone = function(dataObj)
{
    var img = $('#youtubeimg')[0];
    if ( !img.seeThrough )
    {
        img.seeThrough = true;
        img.style.position = "absolute";
        $(img).stop().animate({opacity:".3"},300);
    }

    var gData = $('#youtubecomplete')[0];
    while ( gData.firstChild )
    {
        gData.removeChild(gData.firstChild);
    }

    var corArray = dataObj[1];
    completions[providerIndex.youtube] = [];
    for ( var gdCt = 0; gdCt < corArray.length; gdCt++ )
    {
        var curCor = corArray[gdCt][0];
        var div = AddSuggestion(gData, curCor, providerIndex.youtube);
        completions[providerIndex.youtube][gdCt] = div;
    }
}

function fxsearch(data)
{
   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#yahoocomplete')[0];
   var suggestionImg = $('#yahooimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).stop().animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   allCompletionsLeft = [];

   var terms = [];
   if ( data.length > 1 )
   {
       terms = data[1];
       log("Terms: " + terms);
   }

   completions[providerIndex.yahoo] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       if (allCompletionsLeft.length > 10 )
       {
           break;
       }

       var div = AddSuggestion(suggestionDiv, term, providerIndex.yahoo);
       completions[providerIndex.yahoo][termCt] = div;
   }
}

function updateWiki(data)
{
    if ( !data || !data.length )
        return;

    var searchBox = $('#searchinput')[0];
    var suggestionDiv = $('#wikipediacomplete')[0];
    var suggestionImg = $('#wikipediaimg')[0];

    if ( !suggestionImg.seeThrough )
    {
        suggestionImg.seeThrough = true;
        suggestionImg.style.position = "absolute";
        $(suggestionImg).stop().animate({opacity:".3"},300);
    }

    while( suggestionDiv.firstChild )
    {
        suggestionDiv.removeChild(suggestionDiv.firstChild);
    }

    allCompletionsLeft = [];

    var terms = [];
    if ( data.length > 1 )
    {
        terms = data[1];
        log("Terms: " + terms);
    }

    completions[providerIndex.wikipedia] = [];
    for (var termCt = 0; termCt < terms.length; termCt++ )
    {
        var term = terms[termCt];
        if (allCompletionsLeft.length > 10 )
        {
            break;
        }

        var div = AddSuggestion(suggestionDiv, term, providerIndex.wikipedia);
        completions[providerIndex.wikipedia][termCt] = div;
    }
}


function updateAnswers(data) {
    if ( !data || !data.length )
        return;

    var searchBox = $('#searchinput')[0];
    var suggestionDiv = $('#answerscomplete')[0];
    var suggestionImg = $('#answersimg')[0];

    if ( !suggestionImg.seeThrough ) {
        suggestionImg.seeThrough = true;
        suggestionImg.style.position = "absolute";
        $(suggestionImg).stop().animate({opacity:".3"},300);
    }

    while( suggestionDiv.firstChild ) {
        suggestionDiv.removeChild(suggestionDiv.firstChild);
    }

    var terms = [];
    if ( data.length >= 2 ) {
        terms = data[1].data;
        log("Terms: " + terms);
    }

    completions[providerIndex.answers] = [];
    for (var termCt = 0; termCt < terms.length; termCt++ ) {
      if (terms[termCt] && terms[termCt].title) {
        var term = terms[termCt].title;
        var div = AddSuggestion(suggestionDiv, term, providerIndex.answers);
        completions[providerIndex.answers][termCt] = div;
      }
    }
}


function updateAsk(data)
{
    if ( !data || !data.length )
        return;

    var searchBox = $('#searchinput')[0];
    var suggestionDiv = $('#askcomplete')[0];
    var suggestionImg = $('#askimg')[0];

    if ( !suggestionImg.seeThrough )
    {
        suggestionImg.seeThrough = true;
        suggestionImg.style.position = "absolute";
        $(suggestionImg).stop().animate({opacity:".3"},300);
    }

    while( suggestionDiv.firstChild )
    {
        suggestionDiv.removeChild(suggestionDiv.firstChild);
    }

    var terms = [];
    if ( data.length > 1 )
    {
        terms = data[1];
    }

    completions[providerIndex.ask] = [];
    for (var termCt = 0; termCt < terms.length; termCt++ )
    {
        var term = terms[termCt].replace(/<[^>]+>/g,"");
        var div = AddSuggestion(suggestionDiv, term, providerIndex.ask);
        completions[providerIndex.ask][termCt] = div;
    }
}

var sas_SearchAutoSuggest = {};
sas_SearchAutoSuggest.setData = function( data )
{
    if ( !data )
        return;

    var msnData = data[1];

    var searchBox = $('#searchinput')[0];
    var suggestionDiv = $('#livecomplete')[0];
    var suggestionImg = $('#liveimg')[0];

    if ( !suggestionImg.seeThrough )
    {
        suggestionImg.seeThrough = true;
        suggestionImg.style.position = "absolute";
        $(suggestionImg).animate({opacity:".3"},300);
    }

    while( suggestionDiv.firstChild )
    {
        suggestionDiv.removeChild(suggestionDiv.firstChild);
    }

    var terms = msnData;

    completions[providerIndex.live] = [];
    for (var termCt = 0; termCt < terms.length; termCt++ )
    {
        var term = terms[termCt]
        var div = AddSuggestion(suggestionDiv, term, providerIndex.live);
        completions[providerIndex.live][termCt] = div;
    }
}

function updateAmazon()
{
   var results = completion;

   var terms = [];
   if ( results.length > 1 )
   {
       terms = results[1];
       log("Terms: " + terms);
   }

   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#amazoncomplete')[0];
   var suggestionImg = $('#amazonimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.amazon] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term, providerIndex.amazon);
       completions[providerIndex.amazon][termCt] = div;
   }
}

function updateBuy(data)
{
   var terms = data.result;//.suggestions;

   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#buycomplete')[0];
   var suggestionImg = $('#buyimg')[0];

   if ( !suggestionImg.seeThrough ) {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild ) {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.buy] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ ) {
       var term = terms[termCt][0];
       var div = AddSuggestion(suggestionDiv, term, providerIndex.buy);
       completions[providerIndex.buy][termCt] = div;
   }
}

window.vjo = {};
window.vjo.darwin = {};
window.vjo.darwin.domain = {};
window.vjo.darwin.domain.finding = {};
window.vjo.darwin.domain.finding.autofill = {};
window.vjo.darwin.domain.finding.autofill.AutoFill = {};
window.vjo.darwin.domain.finding.autofill.AutoFill._do = updateEbay;

function updateEbay(data)
{
   var terms = (data["res"] ? data.res.sug : "");

   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#ebaycomplete');
   var suggestionImg = $('#ebayimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   suggestionDiv.empty();
   completions[providerIndex.ebay] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv[0], term, providerIndex.ebay);
       completions[providerIndex.ebay][termCt] = div;
   }
}

function updateOco(data) {
   var terms = data['suggestions'];
   if ( !terms )
       return;
   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#overstockcomplete')[0];
   var suggestionImg = $('#overstockimg')[0];

   if ( !suggestionImg.seeThrough ) {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild ) {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.overstock] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ ) {
       var term = terms[termCt];
       if (term["query"]) {
         var result = term["query"];
         var div = AddSuggestion(suggestionDiv, result, providerIndex.overstock);
         completions[providerIndex.overstock][termCt] = div;
       }
   }
}

function typeaheadResult(data) {
   if ( !data || !data.R )
        return;

   var terms = data.R;

   var searchBox = $('#searchinput')[0];
   var suggestionDiv = $('#walmartcomplete')[0];
   var suggestionImg = $('#walmartimg')[0];

   if ( !suggestionImg.seeThrough ) {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild ) {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.walmart] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ ) {
       var term = terms[termCt][0];
       if ( termCt > 0 )
           term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term, providerIndex.walmart);
       completions[providerIndex.walmart][termCt] = div;
   }
}

function jQuery1_1(data)
{
   var terms = data["titles"].values.concat(data["people"].values);

   var searchBox = $('#searchinput');
   var suggestionDiv = $('#netflixcomplete')[0];
   var suggestionImg = $('#netfliximg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.netflix] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term.pName.replace(/(<em>|<\/em>)/g,"").replace(/&nbsp;/,"&"), providerIndex.netflix);
       completions[providerIndex.netflix][termCt] = div;
   }
}

function updateChaCha(data)
{
   var terms = data["results"];

   var searchBox = $('#searchinput');
   var suggestionDiv = $('#chachacomplete')[0];
   var suggestionImg = $('#chachaimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.chacha] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term.name, providerIndex.chacha);
       completions[providerIndex.chacha][termCt] = div;
   }
}

function updateQQ(data)
{
   var terms = data.split("\n");

   var searchBox = $('#searchinput');
   var suggestionDiv = $('#qqcomplete')[0];
   var suggestionImg = $('#qqimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   completions[providerIndex.qq] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt].split("\t");
       var div = AddSuggestion(suggestionDiv, term[1], providerIndex.qq);
       completions[providerIndex.qq][termCt] = div;
   }
}

function GetPagePositions(layout)
{
    var width = document.body.clientWidth;
    if ( width < 880 )
    {
        width = 880;
    }

    return GetPositions(layout, width, 85)
}

function GetPositions(layout, width, top)
{
    switch( layout )
    {
        case "star": 
        default: return GetStarPositions( width, top );
    }
}

function GetStarPositions(width, top)
{
    var starShoulder = top;
    var starFeet = top + 245; 
    var starMod = -110;
    var perLevel = 250;

    var searchPosition = { x:Math.floor(width/2) - 50 + starMod, y: 245}; 
    var positions = [   {x: Math.floor(width * 2.5 / 5)  + starMod, y:20 },
                        {x: Math.floor(width * 4 / 5) + starMod + 30, y:starShoulder},
                        {x: Math.floor(width * 4 / 5) + starMod + 30, y:starFeet},
                        {x: Math.floor(width * 3 / 5) + starMod + 40, y:starFeet + 80},
                        {x: Math.floor(width * 2 / 5) + starMod + 20, y:starFeet + 80},
                        {x: Math.floor(width * 1 / 5) + starMod, y:starFeet},
                        {x: Math.floor(width * 1 / 5) + starMod, y:starShoulder},
                        {x: Math.floor(width * 4 / 5) + starMod + 40, y:starFeet + perLevel},
                        {x: Math.floor(width * 3 / 5) + starMod + 40, y:starFeet + 80 + perLevel},
                        {x: Math.floor(width * 2 / 5) + starMod + 20, y:starFeet + 80 + perLevel},
                        {x: Math.floor(width * 1 / 5) + starMod, y:starFeet + perLevel},
                        {x: Math.floor(width * 4 / 5) + starMod + 40, y:starFeet + (2*perLevel)},
                        {x: Math.floor(width * 3 / 5) + starMod + 40, y:starFeet + 80 + (2*perLevel)},
                        {x: Math.floor(width * 2 / 5) + starMod + 20, y:starFeet + 80 + (2*perLevel)},
                        {x: Math.floor(width * 1 / 5) + starMod, y:starFeet + (2*perLevel)}
                    ];

    var fleft = { x: positions[0].x - 80, y: positions[0].y }; 
    var fright = { x: positions[0].x + 200, y: positions[0].y }; 

   return {width: width, frameLeftPosition: fleft, frameRightPosition: fright, searchPosition: searchPosition, positions: positions };
}

function GetMiniPositions(layout, width, height, top, left)
{
    switch( layout )
    {
        case "star": 
        default: return GetMiniStarPositions( width, height, top, left);
    }
}

function GetMiniStarPositions( width, height, top, left)
{
    var starShoulder = top + 20;
    var starFeet = top + height; 
    var perLevel = 40;

    var positions = [   {x: Math.floor(width * 2.5 / 5) + left, y:top },
                        {x: Math.floor(width * 4 / 5) + left, y:starShoulder},
                        {x: Math.floor(width * 4 / 5) + left, y:starFeet},
                        {x: Math.floor(width * 3 / 5) + left, y:starFeet + 23},
                        {x: Math.floor(width * 2 / 5) + left, y:starFeet + 23},
                        {x: Math.floor(width * 1 / 5) + left, y:starFeet},
                        {x: Math.floor(width * 1 / 5) + left, y:starShoulder},
                        {x: Math.floor(width * 4 / 5) + left, y:starFeet + perLevel},
                        {x: Math.floor(width * 3 / 5) + left, y:starFeet + 23 + perLevel},
                        {x: Math.floor(width * 2 / 5) + left, y:starFeet + 23 + perLevel},
                        {x: Math.floor(width * 1 / 5) + left, y:starFeet + perLevel},
                        {x: Math.floor(width * 4 / 5) + left, y:starFeet + (2*perLevel)},
                        {x: Math.floor(width * 3 / 5) + left, y:starFeet + 23 + (2*perLevel)},
                        {x: Math.floor(width * 2 / 5) + left, y:starFeet + 23 + (2*perLevel)},
                        {x: Math.floor(width * 1 / 5) + left, y:starFeet + (2*perLevel)},
                    ];

   return {width: width, positions: positions };
}

var engines = [
               "google",
               "amazon",
               "yahoo",
               "live",
               "youtube",
               "answers",
               "wikipedia",
               "ebay",
               "buy",
               "overstock"
             ];

