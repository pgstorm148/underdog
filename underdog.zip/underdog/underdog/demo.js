var demoInterval = null;
var prefixes = [
    "cookie",
    "star",
    "shaya",
    "1-4 infantry hohenfels",
    "ipod",
    "man",
    "child",
    "cold",
    "transist",
    "matt",
    "roxanne",
    "cole",
    "grant",
    "kaylie",
    "oak",
    "steak",
    "pipe",
    "book",
    "lev",
    "duck",
    "training",
    "element",
    "flu",
    "night",
    "right",
    "foo",
    "tiger",
    "chemistry",
    "rub",
    "appl",
    "passage",
    "marble",
    "manny",
    "travel",
];

function ToggleDemo()
{
    if ( demoInterval == null )
    {
        StartDemo();
    }
    else
    {
        StopDemo();
    }
}

function StopDemo()
{
    clearInterval(demoInterval);
    demoInterval = null;

    try
    {
        var demolink = document.getElementById("demolink");
        if ( demolink )
        {
            while (demolink.firstChild)
            {
                demolink.removeChild(demolink.firstChild);
            }

            demolink.appendChild(document.createTextNode("demo"));
        }
    }
    catch(ex)
    {
    }
}

function StartDemo()
{
    if ( demoInterval )
    {
        clearInterval(demoInterval);
    }

    try
    {
        var demolink = document.getElementById("demolink");
        if ( demolink )
        {
            while (demolink.firstChild)
            {
                demolink.removeChild(demolink.firstChild);
            }

            demolink.appendChild(document.createTextNode("stop demo"));
        }
    }
    catch(ex)
    {
    }

    demoInterval = setInterval(Continous, 7000);
    Continous();
}

function Continous()
{
    PlaceProvider(Math.floor(Math.random() * 100) % 7, true);
    setTimeout(ContinuousDemo,500);
}

var calls = 0;
function ContinuousDemo()
{
    TypeItOut(prefixes[Math.floor(Math.random() * 100) % prefixes.length ]);
}

function TypeItOut(value)
{
    if ( !value )
        return;

    try
    {
        var searchBox = document.getElementById("searchinput");

        for (var cCt = 0; cCt < value.length; cCt++ )
        {
            var subVal = value.substr(0, cCt + 1);
            setTimeout((function( sBox, val) { return ( function() { sBox.value = val; } ); })(searchBox, subVal), 200*cCt + 1);
        }

        setTimeout((function( sBox, val) { return ( function() { sBox.value = val; } ); })(searchBox, subVal), 200*value.length + 1);

        setTimeout(function() { GetSuggs(value); }, value.length * 200);
    }
    catch(ex)
    {
    }
}

function GetSuggs(value)
{
    GetSearchSuggestions({keyCode: 32 });
    setTimeout(ShowButton,100);
}

StartDemo();
