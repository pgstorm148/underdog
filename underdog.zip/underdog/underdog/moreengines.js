providerIndex["yandex"] = 12;
providerIndex["naver"] = 13;
providerIndex["youku"] = 14;
providerIndex["baidu"] = 15;
providerIndex["aliexpress"] = 16;

var goodsearch;
var yandex;
var naver;
var baiduholder;

function BuildMoreProviders() {
    yandex = new providerObject( "yandex", providerIndex.yandex, 
                                     "https://www.yandex.com/favicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/yandex.png",
                                     "https://yandex.ru/yandsearch?stpar2=%2Fh1%2Ftm295%2Fs3&stpar4=%2Fs3&stpar1=%2Fu0&text=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "yandex.ru", 
                                     "https://suggest.yandex.ru/suggest-ya.cgi?ct=text/html&part=",
                                     feedTypes.external); 
    yandex.BuildDiv();

    providers["yandex"] = yandex;
    allProviders[allProviders.length] = yandex;
    providerLookup[providerIndex.yandex] = yandex;

    naver = new providerObject( "naver", providerIndex.naver, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/naverfav.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/naver.gif",
                                     "https://search.naver.com/search.naver?where=nexearch&sm=top_sug&fbm=1&ie=utf8&query=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "naver.com", 
                                     "https://ac.search.naver.com/autocompl?frm=nx&r=1&m=0&q=",
                                     feedTypes.external); 

    naver.BuildDiv();

    providers["naver"] = naver;
    allProviders[allProviders.length] = naver;
    providerLookup[providerIndex.naver] = naver;

    baiduholder = new providerObject( "baidu", providerIndex.baidu, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/baidufavicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/baidu.gif",
                                     "https://www.baidu.com/s?wd=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "baidu.com", 
                                     "http://suggestion.baidu.com/su?p=3&t=999999999999&wd=",
                                     feedTypes.external); 
    //baiduholder.enc = "gb2312";
    baiduholder.BuildDiv();
    providers["baidu"] = baiduholder;
    allProviders[allProviders.length] = baiduholder;
    providerLookup[providerIndex.baidu] = baiduholder;

    aliexpressholder = new providerObject( "aliexpress", providerIndex.aliexpress, 
                                     "https://dqmlg7taqp2lg.cloudfront.net/alifavicon.ico",
                                     "https://dqmlg7taqp2lg.cloudfront.net/aliexpress.png",
                                     "https://www.aliexpress.com/wholesale?catId=0&initiative_id=SB_20171111183920&SearchText=",
                                     "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&context=&callback=InsertGoogleResults&start=0&rsz=small&q=", 
                                     "aliexpress.com",
                                     "https://soovle.com/aliexpress?q=",
                                     feedTypes.local);
    aliexpressholder.BuildDiv();
    providers["aliexpress"] = aliexpressholder;
    allProviders[allProviders.length] = aliexpressholder;
    providerLookup[providerIndex.aliexpress] = aliexpressholder;
}

var suggest = new Object();
suggest.apply = function (data)
{
   var searchBox = $('#searchinput');
   var suggestionDiv = $('#yandexcomplete')[0];
   var suggestionImg = $('#yandeximg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   var terms = [];
   if ( data.length > 1 )
   {
       terms = data[1];
       log("Terms: " + terms);
   }

   completions[providerIndex.yandex] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term, providerIndex.yandex);
       completions[providerIndex.yandex][termCt] = div;
   }
}

function set_cc(nodata, data)
{
   var searchBox = $('#searchinput');
   var suggestionDiv = $('#navercomplete')[0];
   var suggestionImg = $('#naverimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   var terms = [];
   if ( data.length > 1 )
   {
       terms = data;
       log("Terms: " + terms);
   }

   completions[providerIndex.naver] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term, providerIndex.naver);
       completions[providerIndex.naver][termCt] = div;
   }
}
function ac_show() {};
var qs_ac_id = null;

function updateYouku(data)
{
   var searchBox = $('#searchinput');
   var suggestionDiv = $('#youkucomplete')[0];
   var suggestionImg = $('#youkuimg')[0];

   if ( !suggestionImg.seeThrough )
   {
       suggestionImg.seeThrough = true;
       suggestionImg.style.position = "absolute";
       $(suggestionImg).animate({opacity:".3"},300);
   }

   while( suggestionDiv.firstChild )
   {
       suggestionDiv.removeChild(suggestionDiv.firstChild);
   }

   var terms = [];
   if ( data.length > 1 )
   {
       terms = data;
       log("Terms: " + terms);
   }

   completions[providerIndex.youku] = [];
   for (var termCt = 0; termCt < terms.length; termCt++ )
   {
       var term = terms[termCt];
       var div = AddSuggestion(suggestionDiv, term["keyword"], providerIndex.youku);
       completions[providerIndex.youku][termCt] = div;
   }
}

//window.baidu.sug({q:'soo',p:true,s:['soojin','sooyuu','soogle','soon','soogou','soohu','soso','soougou' ,'soom','sougou']});
window.baidu = {};
window.baidu.sug = function ( data ) {
   var searchBox = $('#searchinput');
   var suggestionDiv = $('#baiducomplete')[0];
   var suggestionImg = $('#baiduimg')[0];

    var img = $('#baiduimg')[0];
    if ( !img.seeThrough )
    {
        img.seeThrough = true;
        img.style.position = "absolute";
        $(suggestionImg).animate({opacity:".3"},300);
    }

    var gData = $('#baiducomplete')[0];
    while ( gData.firstChild ) {
        gData.removeChild(gData.firstChild);
    }

    var corArray = data.s;
    completions[providerIndex.baidu] = [];
    for ( var gdCt = 0; gdCt < corArray.length; gdCt++ )
    {
        var curCor = corArray[gdCt];
        var div = AddSuggestion(suggestionDiv, curCor, providerIndex.baidu);
        completions[providerIndex.baidu][gdCt] = div;
    }
}

//window.baidu.sug({q:'soo',p:true,s:['soojin','sooyuu','soogle','soon','soogou','soohu','soso','soougou' ,'soom','sougou']});
window.aliExpressHandler = () => {
  setTimeout(function() {
    updateAliExpress(window.intelSearchData);
  }, 1);
};
window.updateAliExpress = function ( data ) {
  var searchBox = $('#searchinput');
  var suggestionDiv = $('#aliexpresscomplete')[0];
  var suggestionImg = $('#aliexpressimg')[0];

  var img = suggestionImg;
  if ( !img.seeThrough ) {
      img.seeThrough = true;
      img.style.position = "absolute";
      $(suggestionImg).animate({opacity:".3"},300);
  }

  var gData = $('#aliexpresscomplete')[0];
  while ( gData.firstChild ) {
      gData.removeChild(gData.firstChild);
  }

  var corArray = data.keyWordDTOs;
  completions[providerIndex.aliexpress] = [];
  for ( var gdCt = 0; gdCt < corArray.length; gdCt++ ) {
    var curCor = corArray[gdCt].keywords;
    if (curCor) {
      var div = AddSuggestion(suggestionDiv, curCor, providerIndex.aliexpress);
      completions[providerIndex.aliexpress][gdCt] = div;
    }
  }
}

